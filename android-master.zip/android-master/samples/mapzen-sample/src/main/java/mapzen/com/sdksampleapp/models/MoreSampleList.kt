package mapzen.com.sdksampleapp.models

/**
 * List of [Sample]s for the more section to display.
 */
class MoreSampleList {

  companion object {
    @JvmStatic val MORE_SAMPLES = arrayOf<Sample>()
  }
}
