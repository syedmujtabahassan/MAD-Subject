package mapzen.com.sdksampleapp.models

/**
 * List of [Sample]s for the search section to display.
 */
class SearchSampleList {

  companion object {
    @JvmStatic val SEARCH_SAMPLES = arrayOf<Sample>()
  }
}
