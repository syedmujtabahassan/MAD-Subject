package com.mapzen.android.core;

import dagger.Module;

/**
 * Dependency injection module for components that do not depend on Android components.
 */
@Module public class CommonModule {

}
