### Description

### Steps to Reproduce

### Mapzen SDK & Android Version
