package com.mapzen.android.graphics.model;

/**
 * Camera types.
 */
public enum CameraType {
  PERSPECTIVE,
  ISOMETRIC,
  FLAT,
}
