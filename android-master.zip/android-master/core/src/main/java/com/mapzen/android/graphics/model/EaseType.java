package com.mapzen.android.graphics.model;

/**
 * Animation ease types.
 */
public enum EaseType {
  LINEAR,
  CUBIC,
  QUINT,
  SINE,
}
