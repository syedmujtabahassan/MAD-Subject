package com.mapzen.android.graphics;

import com.mapzen.tangram.TouchInput;

/**
 *
 */
public class TestLongPressResponder implements TouchInput.LongPressResponder {
  @Override public void onLongPress(float x, float y) {

  }
}
