package com.mapzen.android.core.test;

public final class R {
  public static final class id {
    public static final int mapzen_api_key = 0x00000001;
  }
}
