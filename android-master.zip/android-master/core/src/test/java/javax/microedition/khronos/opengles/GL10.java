package javax.microedition.khronos.opengles;

public class GL10 {
}
