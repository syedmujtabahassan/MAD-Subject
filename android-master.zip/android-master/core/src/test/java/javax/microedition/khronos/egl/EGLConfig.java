package javax.microedition.khronos.egl;

public class EGLConfig {
}
